#include "calculatrice.h"

void
calculatriceprog_1(char *host)
{
	CLIENT *clnt;
	operande  op;
	int   id_Reg;
	long  *res_somme;	
	long  *res_soustraire;
	long  *res_multiplier;
	int   *res_memoriser;	
	long  *res_extraire;
	void  *res_allumer;
	char  *allumer_arg;


#ifndef	DEBUG
	clnt = clnt_create (host, CALCULATRICEPROG, CALCULATRICEVERS, "udp");
	if (clnt == NULL) {
		clnt_pcreateerror (host);
		exit (1);
	}
#endif	/* DEBUG */

	res_allumer = allumer_1((void*)&allumer_arg, clnt);
	 if (res_allumer == (void *) NULL) {
	 	clnt_perror (clnt, "Erreur d'appel : allumer !");
	 }	
	printf("Initialisation réussie !\n");

	// Appel méthode ajouter_1
	op.x=4; op.y=2;
	res_somme = ajouter_1(&op, clnt);
	if (res_somme == (long *) NULL) {
		clnt_perror (clnt, "Erreur d'appel : ajouter !");
	}
	printf("somme : %d + %d = %ld \n", op.x, op.y, *res_somme);

	// Appel méthode soustraire_1
	res_soustraire = soustraire_1(&op, clnt);
	if (res_soustraire == (long *) NULL) {
		clnt_perror (clnt, "Erreur d'appel : soustraire !");
	}
	printf("soustraction : %d - %d = %ld \n", op.x, op.y, *res_soustraire);

	// Appel méthode multiplier_1
	res_multiplier = multiplier_1(&op, clnt);
	if (res_multiplier == (long *) NULL) {
		clnt_perror (clnt, "Erreur d'appel : multiplier !");
	}
	printf("multiplication : %d * %d = %ld \n", op.x, op.y, *res_multiplier);	
	
	// Appel méthode memorisedernierresultat_1
	id_Reg = 3; 
	 res_memoriser = memoriser_1(&id_Reg, clnt);
	 if (res_memoriser == (int *) NULL) {
	 	clnt_perror (clnt, "Erreur d'appel : memoriser !");
	 }
	if(*res_memoriser == 1) {
		printf("Mémorisation réussie en registre %d : \n", id_Reg);
	}else if ( *res_memoriser == 0){
		printf("Mémorisation refusée en registre %d : \n", id_Reg);
	}

	// Appel méthode extraireme_1
	id_Reg = 3;
	res_extraire = extraire_1(&id_Reg, clnt);
	if (res_extraire == (long *) NULL) {
		clnt_perror (clnt, "Erreur d'appel : extraire !");
	 }
	printf("Retour d'extraction en registre %d : %ld \n", id_Reg, *res_extraire);
	
#ifndef	DEBUG
	clnt_destroy (clnt);
#endif	 /* DEBUG */
}


int
main (int argc, char *argv[])
{
	char *host;

	if (argc < 2) {
		printf ("usage: %s server_host\n", argv[0]);
		exit (1);
	}
	host = argv[1];
	calculatriceprog_1 (host);
exit (0);
}
