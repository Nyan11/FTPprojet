#include "calculatrice.h"

long registres[nbReg];
int der_val;

long *
ajouter_1_svc(operande *op, struct svc_req *rqstp)
{
	static long  result;
	result = op->x + op->y;
	der_val = result;
	printf("La fonction ajouter est appelée\n");
	return &result;
}

long *
soustraire_1_svc(operande *op, struct svc_req *rqstp)
{
	static long  result;
	result = op->x - op->y;
	der_val = result;
	printf("La fonction soustraire est appelée\n");
	return &result;
}

long *
multiplier_1_svc(operande *op, struct svc_req *rqstp)
{
	static long  result;
	result = op->x * op->y;
	der_val = result;
	printf("La fonction multiplier est appelée\n");
	return &result;
}

int *
memoriser_1_svc(int *num_Reg, struct svc_req *rqstp)
{
	static int  result;
	if (*num_Reg <= nbReg) {
		registres[*num_Reg-1] = der_val;
		result = 1;
	} else result = 0;
	printf("La fonction memoriser est appelée\n");
	return &result;
}

long *
extraire_1_svc(int *num_Reg, struct svc_req *rqstp)
{
	static long  result;
	if( *num_Reg <= nbReg) {
		result = registres[*num_Reg-1];
	} else result = 0.0;
	return &result;
}

void *
allumer_1_svc(void *arg, struct svc_req *rqstp)
{
	static char * result;
	int i;
	for(i = 0; i <= nbReg; i++) {
		registres[i] = 0.0;
	}
	printf("La fonction allumer est appelée !\n");
	return (void *) &result;
}
